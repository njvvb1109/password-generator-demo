import random
import string

def generate_password(length=8):
    """
    Demo version: Generates a random password with a maximum length of 8 characters.
    Includes uppercase, lowercase, digits, and special characters.
    """
    if length > 8:
        print("Demo version: Password length is limited to 8 characters.")
        length = 8
    
    characters = string.ascii_uppercase + string.ascii_lowercase + string.digits + string.punctuation
    password = ''.join(random.choice(characters) for _ in range(length))
    return password

if __name__ == "__main__":
    print("Demo Password:", generate_password())
    print("Demo Password (attempted length 12):", generate_password(length=12))